ክሊኒክ ሲስተም new — የፋይሎች ማስታወሻ
==================================

Firebase ፕሮጀክት፦ clinic-new-4489d
GitHub ማከማቻ (ለመፍጠር)፦ clinic-new
አድራሻ፦ https://aburumeysaadi1111-crypto.github.io/clinic-new/

ወደ GitHub የሚጫኑት ፋይሎች (ሁሉም .js ፋይሎች + index.html + sw.js + የራስህ style.css)፦
  index.html, sw.js, app.js, backup.js, firestore-sync.js, license.js, security.js,
  patients.js, doctors.js, laboratory.js, radiology.js, diagnostics.js, pharmacy.js,
  emergency.js, payments.js, reports.js, phem-report.js, recycle.js, notices.js,
  lab-catalog.js, ethiopian-date.js
  + የክሊኒኩ ዋናው style.css (ከመጀመሪያ ፋይሎችህ፤ የሱቁን style.css አትጠቀም!)

ወደ GitHub የማይጫን፦
  firestore.rules  — Firebase Console ውስጥ የሚለጠፍ የደህንነት ደንብ (ማጣቀሻ)
  README.txt       — ይህ ማስታወሻ

የተቀየሩ ነገሮች (ከድሮው ክሊኒክ ኮድ ጋር ሲነጻጸር)፦
  backup.js          አዲስ Firebase መረጃ፤ ረጅም ሚስጥራዊ Clinic ID (128-bit)፤ መጠባበቂያ በቁርጥራጭ
                     (ከ1 MiB ገደብ በላይ እንዳይወድቅ)፤ ለውጥ ያልተደረገበት እንዳይደገም፤ ኢንተርኔት ሲቋረጥ
                     ለውጦች እንዲቀመጡ (offline cache)
  firestore-sync.js  የተቀየሩት ብቻ ይላካሉ፤ በ400 ቁርጥራጭ (ድሮ ከ500 በላይ ሲሆን ማመሳሰሉ ይቆም ነበር)፤
                     መግቢያ እስኪጠናቀቅ ይጠበቃል፤ ያልተላከ የራስ ለውጥ በሌላ መሳሪያ ዳታ አይጠፋም
  license.js         ከአገልጋዩ ብቻ ያነባል (offline cache የ7 ቀኑን ገደብ እንዳያሳልፍ)፤ መግቢያ ይጠብቃል
  security.js        የይለፍ ቃል በ PBKDF2 እና በጨው ይቀመጣል (ድሮ ያለ ጨው SHA-256)፤ ነባሪው admin123 መቀየር ግዴታ፤
                     Clinic ID ኮፒ ቁልፍ
  laboratory.js, radiology.js, phem-report.js, reports.js   ጎጂ ጽሑፍ (XSS) መከላከያ ተጨምሯል
  sw.js (አዲስ)       ያለ ኢንተርኔት እንዲከፈት
  index.html         sw.js መመዝገቢያ ተጨምሯል

ፍቃድ መስጠት (ለደንበኛ መሳሪያ)፦
  1) ደንበኛው አፑን ሲከፍት የ Device ID ያያል (DEV-...) — ኮፒ ያደርጋል።
  2) Firebase Console → Firestore → Data → "Start collection" (መጀመሪያ ብቻ) ስም፦ license
  3) Document ID = የደንበኛው Device ID (በትክክል)
  4) Field፦ active  ዓይነት፦ boolean  እሴት፦ true
  5) ፍቃዱን ለመንጠቅ active ን false አድርግ።

አዲስ መሳሪያ ወደ ተመሳሳይ ክሊኒክ ሲጨመር፦
  Admin መሳሪያ → Security → Cloud Backup ክፍል ውስጥ Clinic ID (📋 ኮፒ)።
  በአዲሱ መሳሪያ → "ከCloud ውሂብ መልስ" ሳጥን ውስጥ ID ይለጥፋል።
  Clinic ID የክሊኒኩ ሚስጥር ነው፤ ለክሊኒኩ መሳሪያዎች ብቻ ይሰጥ።

ያልተፈተነ (በእውነተኛ Firebase እና ስልክ ላይ)፦
  - የ Firestore ደንብ በእውነተኛው Firebase ላይ (በራስ ሞዴል ብቻ ተፈትኗል)
  - ባለ ብዙ መሳሪያ እውነተኛ ሙከራ እና የኢንተርኔት መቋረጥ/መመለስ
  - አይፎን/አይፓድ
